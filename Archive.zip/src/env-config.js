require('dotenv').config();
export const dev={
    REACT_APP_BACKEND_URL:'http://localhost:9000'
}
export const prod={
    REACT_APP_BACKEND_URL:'http://covid19report.ir:9000'
}