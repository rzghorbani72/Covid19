export const FETCH_DATA = 'summary/fetch_data';
export const FETCH_SUCCESS = 'summary/fetch_success';
export const FETCH_FAIL = 'summary/fetch_fail';
