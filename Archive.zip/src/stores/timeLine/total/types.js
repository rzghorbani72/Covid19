export const FETCH_DATA = 'totalTimeLine/fetch_data';
export const FETCH_SUCCESS = 'totalTimeLine/fetch_success';
export const FETCH_FAIL = 'totalTimeLine/fetch_fail';
