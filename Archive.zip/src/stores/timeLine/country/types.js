export const FETCH_DATA = 'countryTimeLine/fetch_data';
export const FETCH_SUCCESS = 'countryTimeLine/fetch_success';
export const FETCH_FAIL = 'countryTimeLine/fetch_fail';
