pm2 start ./src/middlewareServer/index.js --name "backend-server"
npm start