pm2 start ./src/middlewareServer/index.js --name "backend-server"
npm run build
npm run prod